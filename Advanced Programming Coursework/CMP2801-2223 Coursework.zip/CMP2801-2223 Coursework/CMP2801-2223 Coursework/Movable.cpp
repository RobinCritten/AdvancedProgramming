#include "Movable.h"

Movable::~Movable() {} //destructor